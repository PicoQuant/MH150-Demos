#ifndef __STDINT_H__
#define __STDINT_H__

#include<inttypes.h>

#endif
