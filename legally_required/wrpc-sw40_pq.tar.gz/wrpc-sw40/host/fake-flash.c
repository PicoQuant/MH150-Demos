#include "flash.h"


void    flash_init(void)
{}

int     flash_write(uint32_t addr, uint8_t *buf, int count)
{ return 0; }

int     flash_read(uint32_t addr, uint8_t *buf, int count)
{ return 0; }

int     flash_erase(uint32_t addr, int count)
{ return 0; }
