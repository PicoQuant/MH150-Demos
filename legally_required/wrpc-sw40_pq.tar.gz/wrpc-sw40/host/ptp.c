#include "wrc_ptp.h"

int wrc_ptp_init(void)
{ return 0; }

int wrc_ptp_set_mode(int mode)
{ return 0; }

int wrc_ptp_get_mode(void)
{ return 0; }

int wrc_ptp_start(void)
{ return 0; }

int wrc_ptp_stop(void)
{ return 0; }

int wrc_ptp_update(void)
{ return 0; }

