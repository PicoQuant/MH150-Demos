void uart_exit(int i);
