
extern struct minipc_pd rpc_getenv;
extern struct minipc_pd rpc_setenv;
extern struct minipc_pd rpc_add;
extern struct minipc_pd rpc_strlen;
extern struct minipc_pd rpc_strcat;
extern struct minipc_pd rpc_stat;
