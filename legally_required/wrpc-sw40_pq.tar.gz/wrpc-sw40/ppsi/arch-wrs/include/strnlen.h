typedef unsigned int size_t;
extern size_t strnlen(const char *s, size_t max);
