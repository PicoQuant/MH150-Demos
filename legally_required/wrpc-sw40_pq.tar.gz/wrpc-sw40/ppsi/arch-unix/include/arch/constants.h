
#ifndef __PPSI_ARCH_CONSTANTS_H__
#define __PPSI_ARCH_CONSTANTS_H__

#ifndef __PPSI_CONSTANTS_H__
#Warning "Please include <ppsi/constants.h> before <arch/constants.h>"
#endif

/* nothing to do here, we keep project-wide defaults */

#endif /* __PPSI_ARCH_CONSTANTS_H__ */
