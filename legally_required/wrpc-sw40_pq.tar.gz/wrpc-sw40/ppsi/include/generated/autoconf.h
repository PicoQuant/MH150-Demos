/*
 *
 * Automatically generated file; DO NOT EDIT.
 * PPSi configuration
 *
 */
#define CONFIG_HAS_P2P 0
#define CONFIG_ARCH "wrpc"
#define CONFIG_OPTIMIZATION 2
#define CONFIG_VLAN_ARRAY_SIZE 1
#define CONFIG_ARCH_LDFLAGS ""
#define CONFIG_E2E 1
#define CONFIG_WRPCSW_ROOT "../wrpc-sw"
#define CONFIG_EXTENSION "whiterabbit"
#define CONFIG_ARCH_WRPC 1
#define CONFIG_VLAN 1
#define CONFIG_ARCH_CFLAGS ""
#define CONFIG_HAS_VLAN 1
#define CONFIG_E2E_ONLY 1
#define CONFIG_CROSS_COMPILE "/opt/gcc-lm32/bin/lm32-elf-"
#define CONFIG_EXT_WR 1
