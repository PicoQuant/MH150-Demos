#include <ppsi/ppsi.h>

/* proto-standard offers all-null hooks as a default extension */
struct pp_ext_hooks  __attribute__((weak)) pp_hooks;
